//Javascript for tab navigation horizontal scroll buttons

//Javascript to make the tab navigation draggable

//Javascript to view tab contents on click tab buttons

